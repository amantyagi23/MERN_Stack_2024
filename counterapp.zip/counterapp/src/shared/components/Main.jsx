
import { useState } from 'react';
import Button from './Button'



const Main = () => {
    const [value,setValue] = useState(-1)

    const increment = ()=>{
      setValue(value+1)
    }
    const decrement = ()=>{
        setValue(value-1)
    }
  return (
    <div>
        <div className='value'>
            {value}
        </div>
        <Button key={1} title={"+"} function={increment}/>
        <Button key={2} title={"Reset"}/>
        <Button key={3} title={"-"} function={decrement}/>

    </div>
  )
}

export default Main