import Main from "./shared/components/Main"





const App = ()=>{
  return (
    <>
    <Main/>
    </>
  )
}

export default App